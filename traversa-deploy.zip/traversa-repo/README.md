# Traversa — Global Premium Transfers & Private Aviation

**traversa.global**

## Platform Overview

Traversa is a premium global transfer and private aviation platform. This repository contains all front-end applications.

## Applications

| File | URL | Description |
|------|-----|-------------|
| `index.html` | `traversa.global` | Marketing site |
| `client.html` | `app.traversa.global` | Client booking app |
| `driver.html` | `driver.traversa.global` | Driver partner app |
| `admin.html` | `ops.traversa.global` | Admin dashboard |

## Deploy to Vercel

1. Import this GitHub repository into Vercel
2. Vercel will automatically detect the `vercel.json` config
3. Deploy — all routes are pre-configured

## Tech Stack

- HTML5 / CSS3 / Vanilla JavaScript
- Claude AI (Anthropic) — AI concierge & support
- Canvas API — animated maps & visualizations
- Progressive Web App (PWA) ready

## Routes

- `/` — Marketing site (traversa.global)
- `/client` — Client app (app.traversa.global)
- `/driver` — Driver app (driver.traversa.global)
- `/admin` — Admin dashboard (ops.traversa.global)

## Contact

- Website: traversa.global
- Email: hello@traversa.global
- Support: support@traversa.global

© 2026 Traversa — traversa.global
